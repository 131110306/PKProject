package com.test.dao;

/**
 * Tinmetable entity. @author MyEclipse Persistence Tools
 */

public class Tinmetable implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer weekNumber;
	private Integer dateNumber;
	private Integer partNumber;
	private String course;
	private String other1;
	private String other2;

	// Constructors

	/** default constructor */
	public Tinmetable() {
	}

	/** minimal constructor */
	public Tinmetable(Integer id, Integer weekNumber, Integer dateNumber,
			Integer partNumber, String course) {
		this.id = id;
		this.weekNumber = weekNumber;
		this.dateNumber = dateNumber;
		this.partNumber = partNumber;
		this.course = course;
	}

	/** full constructor */
	public Tinmetable(Integer id, Integer weekNumber, Integer dateNumber,
			Integer partNumber, String course, String other1, String other2) {
		this.id = id;
		this.weekNumber = weekNumber;
		this.dateNumber = dateNumber;
		this.partNumber = partNumber;
		this.course = course;
		this.other1 = other1;
		this.other2 = other2;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getWeekNumber() {
		return this.weekNumber;
	}

	public void setWeekNumber(Integer weekNumber) {
		this.weekNumber = weekNumber;
	}

	public Integer getDateNumber() {
		return this.dateNumber;
	}

	public void setDateNumber(Integer dateNumber) {
		this.dateNumber = dateNumber;
	}

	public Integer getPartNumber() {
		return this.partNumber;
	}

	public void setPartNumber(Integer partNumber) {
		this.partNumber = partNumber;
	}

	public String getCourse() {
		return this.course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getOther1() {
		return this.other1;
	}

	public void setOther1(String other1) {
		this.other1 = other1;
	}

	public String getOther2() {
		return this.other2;
	}

	public void setOther2(String other2) {
		this.other2 = other2;
	}

}