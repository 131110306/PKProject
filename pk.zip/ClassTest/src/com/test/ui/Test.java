package com.test.ui;

import com.test.dao.Tinmetable;
import com.test.dao.TinmetableDAO;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TinmetableDAO dao=new TinmetableDAO();
		Tinmetable tinmetable=dao.findById(1002);
		System.out.println(tinmetable.getPartNumber().toString());

	}

}
