/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50614
Source Host           : localhost:3306
Source Database       : class

Target Server Type    : MYSQL
Target Server Version : 50614
File Encoding         : 65001

Date: 2015-05-28 15:12:18
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tinmetable`
-- ----------------------------
DROP TABLE IF EXISTS `tinmetable`;
CREATE TABLE `tinmetable` (
  `id` int(6) NOT NULL,
  `week-number` varchar(255) NOT NULL,
  `date-number` varchar(255) NOT NULL,
  `part-number` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `other1` varchar(255) DEFAULT NULL,
  `other2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tinmetable
-- ----------------------------
INSERT INTO `tinmetable` VALUES ('1002', '2', '2', '2', '数学', null, null);
INSERT INTO `tinmetable` VALUES ('1003', '1', '1', '4', '语文', null, null);
INSERT INTO `tinmetable` VALUES ('1004', '1', '1', '1', '物理', null, null);
INSERT INTO `tinmetable` VALUES ('1005', '1', '2', '1', '体育', null, null);
INSERT INTO `tinmetable` VALUES ('5001', '6', '6', '6', '文化', null, null);
INSERT INTO `tinmetable` VALUES ('7777', '7', '7', '7', '体育', null, null);
